from bs4 import BeautifulSoup
import requests

url = "https://www.assemblee-nationale.fr/dyn/deputes/PA718674"

response = requests.get(url)

if response.ok:
    soup = BeautifulSoup(response.text, "html.parser")
    
    # Recherche de la balise <ul> avec la classe spécifique
    ul_button_list = soup.find('ul', class_='button-list _vertical')
    
    # Vérification si la balise <ul> est trouvée
    if ul_button_list:
        # Récupération de tous les liens <a> à l'intérieur de la balise <ul>
        links = ul_button_list.find_all('a', href=True)
        
        # Affichage des attributs href des balises <a>
        for link in links:
            print(link['href'])
    else:
        print("La balise <ul class='button-list _vertical'> n'a pas été trouvée.")
else:
    print("La requête a échoué.")
