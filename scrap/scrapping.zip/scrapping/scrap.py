import re
from bs4 import BeautifulSoup
import requests




def getCollaborateurs(soup):
    ret = []

    #supp de la ligne qui bloque
    ul_pipe_list = soup.find('ul', class_='pipe-list _pb-small _justify-center')
    if ul_pipe_list: # si la balise ul_pipe_list existe
        ul_pipe_list.extract()

    ul_pipe_list = soup.find('ul', class_="pipe-list")

    if ul_pipe_list:
        content = ul_pipe_list.get_text(separator='\n', strip=True)
        for mot in content.split('\n'):
            ret.append(mot)
        ret = ' | '.join(ret)
    return ret.replace("'","''")
  



def getNext(soup, balise, className):
    # Recherche de la balise renseigné en paramètre
    target_span = soup.find(balise, class_=className)
    ret = ""
    if target_span:
        next_tag = target_span.find_next_sibling()
        
        if next_tag:
            ret = next_tag.get_text()
    return ret


def findSocialMedia(soup):
    # si len(listSocialMedia) == 0 alors la personne n'a pas de réseaux sociaux
    listSocialMedia = []
    ul_button_list = soup.find('ul', class_='button-list _vertical')
    if ul_button_list:
        # Récupération de tous les liens <a> à l'intérieur de la balise <ul>
        links = ul_button_list.find_all('a', href=True)

        for link in links:
            listSocialMedia.append(link['href'])
    return listSocialMedia


    

def getInfo(uid):
    url = "https://www.assemblee-nationale.fr/dyn/deputes/"+uid
    tab = []
    response = requests.get(url)

    if response.ok:
        soup = BeautifulSoup(response.text, "html.parser")
        
        # Utilisation de BeautifulSoup pour trouver la divContent spécifique
        divContent = soup.find('div', class_='bloc-content')

        # Vérification si la divContent est trouvée
        if divContent:
            # Concaténer tout le texte extrait des balises enfants de divContent
            texte_complet = '\n'.join(balise.get_text(separator="\n").strip() for balise in divContent)
            tabTmp = []
            # Diviser le texte complet en lignes et l'ajouter à la liste tab
            for ligne in texte_complet.split('\n'):
                if ligne.strip():  # Vérifier si la ligne n'est pas vide
                    tabTmp.append(ligne)
            try:
                
                numeroMois = {'janvier': '01', 'février': '02', 'mars': '03', 'avril': '04', 'mai': '05', 'juin': '06', 'juillet': '07', 'août': '08', 'septembre': '09', 'octobre': '10', 'novembre': '11', 'décembre': '12'}

                tabDateN = tabTmp[1].split(' ')
                dateN = tabDateN[2]+"/"+numeroMois.get(tabDateN[3])+"/"+tabDateN[4]
                tab.append(dateN)
                
                tab.append(tabTmp[4])
                tab.append(tabTmp[5])
                tab.append(tabTmp[7])
            except IndexError:
                tab.append('')
    return soup, tab


#soup, tab = getInfo()
#print(tab)



"""
Données du tab à garder:
1 dateN
4 Commssion
5 job dans la commission
7 nomSuppléant


mail = getNext(soup, 'span', '_colored _bold')
Website = getNext(soup, 'span', 'an-icons-new-tab _colored')
collab = getCollaborateurs(soup)
print("Mail de la personne : ", mail)
print("Site de la personne : ", Website)
print("Collaborateurs : ", collab)
"""



